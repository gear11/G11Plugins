# G11 Carousel

A very simple, non-interactive carousel that can be used either as a WordPress plugin or standalone.

## WordPress
Install 

    [g11-carousel duration="5"]
    <div style="padding: 10px; background-color: red">Hello world!</div>
    <div style="padding: 10px; background-color: green"><a href="http://wordpress.com">I love WordPress</a></div>
    [/g11-carousel]
    
    [g11-carousel]
    <img src="/wp-content/uploads/2015/01/boat.jpg">
    <img src="/wp-content/uploads/2015/01/wine.jpg">
    <img src="/wp-content/uploads/2015/01/onsalt.jpg">
    <img src="/wp-content/uploads/2015/01/dock.jpg">
    <img src="/wp-content/uploads/2015/01/halfshell.jpg">
    <img src="/wp-content/uploads/2015/01/cage-dry.jpg">
    [/g11-carousel]
    
    [g11-carousel height="150px"]
    <img src="/wp-content/uploads/2015/01/boat.jpg">
    <img src="/wp-content/uploads/2015/01/wine.jpg">
    <img src="/wp-content/uploads/2015/01/onsalt.jpg">
    <img src="/wp-content/uploads/2015/01/dock.jpg">
    <img src="/wp-content/uploads/2015/01/halfshell.jpg">
    <img src="/wp-content/uploads/2015/01/cage-dry.jpg">
    [/g11-carousel]


![Screen shot](doc/screenshot.jpg "Screen shot")